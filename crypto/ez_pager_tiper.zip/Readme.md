Little R has intercepted some interesting messages recently.
He believes that there must be some gifts in them, and he has managed to decrypt some of them (partly).
Maybe you can teach him more about crypto?
*BTW pager-tiper is just something for fun :)